# Observable - Remake release naming

- Display name: `Observable - Remake`
- Author/creator: `Bomberbude.de`
- Mod version: `1.0`
- Minimum NeoForge build: `26.1.2.74`
- Generated JAR: `Observable-Remake-V1.0-NeoForge-26.1.2.74.jar`
- Internal mod ID: `observable` (kept for compatibility)

The project remains based on the original Observable project by tasgon and retains the MPL-2.0 license and attribution.
