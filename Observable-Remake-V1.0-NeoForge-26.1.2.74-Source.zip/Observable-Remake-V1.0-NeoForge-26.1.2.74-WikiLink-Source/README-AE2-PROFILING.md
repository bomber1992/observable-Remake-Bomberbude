# Observable: AE2 grid-tick profiling

This source tree adds optional Applied Energistics 2 integration to Observable.

## What is measured

Observable normally profiles Minecraft entity, block entity, scheduled block and
fluid ticks. AE2 automation parts are different: devices such as Storage Buses,
Import Buses and Export Buses are scheduled by AE2's `TickManagerService` and may
share one `ae2:cable_bus` block entity.

The compatibility mixin wraps AE2's per-node `IGridTickable.tickingRequest(...)`
call. Each AE2 grid node receives a separate Observable entry, even when multiple
parts occupy the same cable-bus block.

Names look similar to:

- `ae2:storage_bus [AE2 grid tick, west]`
- `ae2:import_bus [AE2 grid tick, north]`
- addon parts use their own registered item id where available

## Timing calculation

The AE2 hook follows Observable's original data contract exactly:

- `time` is the total measured nanoseconds spent in the device callback.
- `ticks` is the number of measured callback invocations (one increment per call).
- the stored `rate` is `time / ticks`, i.e. average nanoseconds per call.
- with **Normalize results** enabled, the client calculates
  `rate * calls / profileTicks`, which simplifies to `totalTime / profileTicks`
  and is displayed as `µs/t`.
- with normalization disabled, the average callback cost is displayed as `µs/call`.

`ticksSinceLastCall` is intentionally not stored as the invocation count. Using it
there would preserve the normalized result but would change the non-normalized
meaning and the data format expected by the original Observable viewer.

## Optional dependency

AE2 is a `compileOnly` dependency and is not bundled. Observable still starts
without AE2. The compatibility mixin is a soft (`@Pseudo`) target and only applies
when `appeng.me.service.TickManagerService` exists.

The build currently compiles against the AE2 `26.1.10-beta` API from Maven Central.
Change `ae2_version` in `gradle.properties` when targeting another compatible AE2
26.1 release.

## Client display fixes in this revision

- The settings label/value group is centered as one unit at every GUI scale.
- Player entries keep their coloured timing label but no longer render a hitbox.
- The **Profile TPS** button shows `Timer: <seconds>` while profiling and then
  **Uploading...** until the result packet (and chat link) arrives.
- With **Normalize results** enabled, overlay values are total measured CPU time
  divided by the number of server ticks in the profile (`µs/t`). With it disabled,
  the overlay now labels the value accurately as `µs/call`.

## Mixin class-loading compatibility

`Ae2ProfilerSupport` deliberately lives in `observable.compat.ae2`, outside the configured
Mixin package `observable.mixin`. Mixin treats every class below the configured package as
a potential mixin class and prevents transformed target classes from loading such classes
directly. Keeping the helper outside that package avoids `IllegalClassLoadError` while the
actual `Ae2TickManagerMixin` remains under `observable.mixin.compat.ae2`.
