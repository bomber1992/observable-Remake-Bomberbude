# Fixed Bomberbude upload endpoint

The upload endpoint is no longer part of `observable.json` and cannot be changed with `/observable set uploadURL`.
Legacy `uploadURL` entries are ignored and removed the next time the settings file is loaded.

The endpoint is reconstructed from encoded bytes in `UploadEndpoint.kt` so it is not present as a plain-text string in the built JAR. This is obfuscation only. A static credential distributed in a JAR cannot be made cryptographically secret from someone who can inspect or execute that JAR.

For actual credential protection, restrict the upload endpoint server-side, for example by source-IP allowlisting, or issue short-lived signed credentials.
