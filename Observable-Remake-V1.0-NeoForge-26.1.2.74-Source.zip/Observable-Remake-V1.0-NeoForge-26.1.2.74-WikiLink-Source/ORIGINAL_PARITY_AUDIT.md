# Original Observable 5.4.4 parity audit

## Scope

This audit compares the uploaded upstream `observable-5.4.4` source with the
NeoForge 26.1.2.74+ port in this archive. The comparison covers functional source
code, packet models, settings, commands, profiling hooks, result calculations and
client behavior. Fabric support is not part of this port; it is intentionally a
NeoForge-only target.

## Functional parity

### Client

- profiler key binding and reusable profile screen
- duration selection by mouse wheel, clamped to 5–60 seconds
- TPS profiling start and server availability/permission state
- optional tagged sampler
- overlay enable/disable control
- client settings for block distance, entity distance, entity count and normalization
- wiki, Discord and donation links
- profile upload result shown in chat
- local profile export when upload fails
- pack announcement on first level load
- result reset on disconnect

### Server

- operator, single-player and allow-list permission checks
- `/observable` help output
- `/observable config`
- `/observable run <duration>`
- `/observable allow <player>` and `/observable deny <player>`
- `/observable set <setting> <value>`
- `/observable tp <dimension> entity <id>`
- `/observable tp <dimension> position <x> <y> <z>`
- `/observable reset`
- server settings JSON load/save

### Profiling and data

- normal entity ticks
- passenger entity ticks
- block-entity ticks
- scheduled/random block ticks
- fluid ticks
- per-target stack traces
- tagged server sampler and whole-server trace tree
- protobuf serialization, gzip compression and split packet transfer
- diagnostics and mod list
- remote upload and local export fallback
- deobfuscation remapping

### Added port functionality

- optional client/server payload negotiation for mixed modded/unmodded connections
- native 26.1 gizmo overlay instead of the removed private RenderType/VBO path
- separate AE2 grid-node timings for Storage Buses, Import/Export Buses and other
  `IGridTickable` devices
- player timing label without a player hitbox
- centered settings layout
- countdown inside the profiling button

## Settings parity

The values and defaults match upstream:

| Setting | Default | Upstream GUI | Port GUI |
|---|---:|:---:|:---:|
| Minimum visible rate | 0 | no | no |
| Maximum block distance | 128 | yes | yes |
| Maximum entity distance | 2048 | yes | yes |
| Normalize results | true | yes | yes |
| Maximum block count | 2000 | no | no |
| Maximum entity count | 2000 | yes | yes |

The port keeps the same exposed four settings rows. The layout is centered as one
label/value group, and the normalization checkbox now reflects the actual current
value instead of being hardcoded to checked during screen creation.

## Timing formula

Upstream stores for each target:

```text
time  = total measured nanoseconds
calls = number of measured invocations
rate  = time / calls
```

The client then applies:

```text
normalized = rate * calls / profileTicks
           = total measured nanoseconds / profileTicks
```

Therefore:

- normalization enabled: `rate / 1000` is displayed as `µs/t`;
- normalization disabled: `rate / 1000` is displayed as `µs/call`.

The AE2 integration now increments its counter once per `tickingRequest` call,
matching this original contract. `ticksSinceLastCall` remains an AE2 scheduling
argument and is not substituted for Observable's call count.

## Corrections included in this revision

- profiling button countdown reads `Timer: … s`, not `TPS: … s`;
- AE2 call-count semantics now match upstream calculations and viewer data;
- entity label brightness uses upstream's green/yellow/red label calculation;
- block fill/outline colors retain the raw heat-map color;
- player hitboxes remain suppressed while their colored timing labels remain;
- the AE2 helper remains outside the configured Mixin package, preventing the
  reported `IllegalClassLoadError`.

## Verification limits

This is a source-level parity audit and targeted static validation. A complete
NeoForge build/runtime test was not performed in this environment because the port
targets Java 25 while the available JDK is Java 21. The archive should still be
built and tested with Java 25 on clean NeoForge 26.1.2.74 and newer 26.1.2 client/server builds before
publishing a binary release.
