# NeoForge compatibility

This source package targets Minecraft 26.1.2.

- Compile target: `net.neoforged:neoforge:26.1.2.74`
- Runtime dependency range: `[26.1.2.74,26.1.3)`
- Minecraft range: `[26.1.2]`

The lower compile target prevents accidental use of APIs introduced after build 74. The runtime range allows later NeoForge build revisions for Minecraft 26.1.2 without requiring an exact loader build.

This does not override version requirements declared by other installed mods such as AE2.
