package observable.server

/**
 * Fixed upload endpoint for the Bomberbude Observable service.
 *
 * The value is reconstructed at runtime so it is not stored as a plain-text string in the JAR.
 * This is only obfuscation: any secret shipped in a client/server mod can ultimately be recovered
 * by someone who can inspect or execute the JAR.
 */
internal object UploadEndpoint {
    private val encoded = intArrayOf(
        50, 13, 236, 199, 165, 207, 59, 28, 48, 30, 253, 205, 171, 159, 110, 94,
        46, 12, 166, 195, 163, 202, 107, 65, 49, 4, 242, 233, 223, 191, 144, 126,
        21, 56, 8, 254, 152, 165, 156, 99, 13, 48, 19, 251, 199, 162, 130, 54,
        75, 45, 12, 161, 205, 160, 157, 62, 23, 121, 87, 77, 169, 143, 229, 203,
        42, 12, 97, 69, 166, 133, 227, 202, 36, 3, 97, 11, 185, 206, 169, 221,
        51, 74, 112, 87, 190, 148, 242, 218, 102, 21, 37, 104, 29, 164, 138, 184,
        201, 44, 12, 110, 65, 241, 134, 234
    )

    private val value: String by lazy {
        buildString(encoded.size) {
            encoded.forEachIndexed { index, byte ->
                val mask = (0x5A + ((index * 31) and 0xFF)) and 0xFF
                append((byte xor mask).toChar())
            }
        }
    }

    fun url(): String = value
}
