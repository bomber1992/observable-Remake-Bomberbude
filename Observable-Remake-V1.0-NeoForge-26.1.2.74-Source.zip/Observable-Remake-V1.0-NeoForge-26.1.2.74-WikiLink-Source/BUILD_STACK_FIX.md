# Build stack fix for Minecraft / NeoForge 26.1.2

The previous package used Gradle 8.8 while compiling and running with Java 25.
Gradle 8.8 officially supports running only through Java 22. The resulting
unsupported combination caused dependency variant resolution to combine
NeoForge's `modDevApiElements` and `universalJar` variants during
`:compileKotlin`.

This package uses the same core build stack as the official NeoForge 26.1.2
ModDevGradle MDK:

- Gradle 9.2.1
- ModDevGradle 2.0.143
- Java toolchain 25
- Foojay toolchain resolver 1.0.0

The AE2 API dependency remains compile-only, classifier-specific, and
non-transitive. It is not the source of the NeoForge variant collision.

## Windows build

From a fresh extraction directory:

```bat
gradlew.bat --stop
gradlew.bat --version
gradlew.bat clean build --refresh-dependencies
```

The version command must report Gradle 9.2.1. Do not run a globally installed
`gradle` command and do not reuse an old extracted project directory.
