# NeoForge 26.1.2.74+ port notes

## Platform migration

- Removed Architectury and the old multi-loader bootstrap.
- Added a native NeoForge Java entrypoint and native event registration.
- Replaced Architectury networking with NeoForge custom payloads while retaining protobuf encoding, gzip compression and packet splitting.
- Separated all client-only classes and packet handlers from the common/server bootstrap.

## Minecraft 26.1 API migration

- Updated identifiers, command APIs, permissions, teleportation and server lifecycle access.
- Updated GUI rendering to the extraction-based 26.1 screen API.
- Updated fluid, block, entity and block-entity tick mixins to current signatures.
- Replaced the private `RenderType` reflection/VBO overlay with native 26.1 gizmos.
- Updated deobfuscation mapping lookup from the 1.21.1 mapping set to the 1.21.11 mapping set used by the 26.1 line.

## Distribution

- Kotlin 2.3.10 and kotlinx.serialization 1.10.0 are embedded with NeoForge Jar-in-Jar.
- No KotlinForForge installation is required.

- The compile target is the minimum supported build, NeoForge 26.1.2.74. Loader metadata accepts `[26.1.2.74,26.1.3)`, so later NeoForge builds for Minecraft 26.1.2 do not require a separate Observable build.

## Optional-client compatibility

- Both play payloads are registered through `PayloadRegistrar.optional()`.
- Missing Observable payloads no longer fail NeoForge/vanilla connection negotiation.
- All S2C sends are guarded with `NetworkRegistry.hasChannel`, so unmodded clients never receive unsupported payloads.
- C2S sends are also guarded, allowing a modded client to join a server without Observable safely.

## Gradle dependency resolution

- AE2 is compiled from `appliedenergistics2:<version>:api@jar` with transitive resolution disabled.
- This keeps AE2 optional and prevents its published platform metadata from requesting NeoForge's
  `universalJar` in addition to ModDevGradle's `modDevApiElements` variant.
- NeoForge 26.1.2.74 is supplied through one path only: the `neoForge { version = ... }` block. Runtime compatibility is controlled separately by `neo_version_range`.
