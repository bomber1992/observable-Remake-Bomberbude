# Observable 5.4.4 original UI parity for Minecraft 26.1.2

This revision mirrors the original Observable 5.4.4 screen layout and settings behavior.

## Profile screen

- Main buttons: original dimensions and positions (`100 x 20`, centered with an 8-pixel gap).
- Duration line: original position above the buttons.
- Mouse wheel: original 5-second increments, clamped to 5–60 seconds.
- Sampler, overlay, Wiki, Discord and Donate controls: original positions and dimensions.
- During profiling, the start button displays `Timer: <seconds> s` as requested.

## Settings screen

- Numeric fields: original positions `x = width * 3 / 4`, `y = 20/40/60`, size `40 x 20`.
- Labels: original positions `x = width / 4`, with the same Y coordinate as each widget.
- Normalize checkbox: original position `x = width * 3 / 4`, `y = 90`.
- Checkbox initialization is restored to the original hard-coded `true` value.

## Minecraft 26.1.2 rendering correction

The 26.1.2 extraction renderer consumes ARGB colors. The original `0xFFFFFF` RGB literal has therefore been represented as fully opaque `0xFFFFFFFF`; this preserves the original white appearance instead of producing zero-alpha text.

## Build completeness

The Gradle wrapper JAR and properties from the original Observable 5.4.4 source archive are included.
